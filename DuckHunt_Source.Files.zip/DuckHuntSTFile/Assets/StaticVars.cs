﻿using UnityEngine;
using System.Collections;

public class StaticVars : MonoBehaviour {

	public static int gameScore = 0;
	public static int bullets = 3;
}
